✦ Custom Cursors ✦
by katekoteko

BlueSky: https://bsky.app/profile/katekoteko.bsky.social
Twitter: https://x.com/katekoteko
VGen: https://vgen.co/katekoteko

Thank you for your order!


✦✦✦ Installation ✦✦✦

1. Extract the .zip file
2. Open the "Cursor" folder
3. Right click on "install.inf" > Install
4. In pop-up window in the scheme section choose the cursor set (if it isn't selected) and press "OK"
5. Accept to replace the cursor scheme
6. Done!


✦✦✦ !If cursor has no animation through OBS or StreamLabs! ✦✦✦
Window Capture Settings:
- Make sure, that Capture method is Windows 10 (1903 and up) and Capture Cursor is checked
Display Capture Settings:
- If capture method is DXGI Desktop Duplication, make sure Capture Cursor is unchecked
- If capture method is Windows 10 (1903 and up), make sure Capture Cursor is checked



*Selling are not allowed