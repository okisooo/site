import { Assets, getTimestampsFromMedia, ActivityType } from 'premid';
const presence = new Presence({ clientId: '1505219461152636949' });
const browsingTimestamp = Math.floor(Date.now() / 1000);
var ActivityAssets;
(function (ActivityAssets) {
    ActivityAssets["Logo"] = "https://okiso.net/icon.png";
})(ActivityAssets || (ActivityAssets = {}));
presence.on('UpdateData', async () => {
    const { pathname } = document.location;
    // @ts-ignore
    const presenceData = {
        largeImageKey: ActivityAssets.Logo,
        largeImageText: 'okiso.net',
        startTimestamp: browsingTimestamp,
        buttons: [
            { label: 'Visit okiso.net', url: `https://okiso.net${pathname === '/' ? '' : pathname}` }
        ]
    };
    // ─── Home Page ───
    if (pathname === '/') {
        const pageEl = document.querySelector('[data-premid-page]');
        const page = pageEl?.getAttribute('data-premid-page');
        if (page === 'home') {
            // Check for live broadcast
            const isLive = document.querySelector('[data-premid-live="true"]');
            if (isLive) {
                presenceData.details = 'Watching Live Broadcast';
                presenceData.state = '🔴 LIVE on Twitch';
                presenceData.smallImageKey = Assets.Live;
                presenceData.smallImageText = 'Live';
                delete presenceData.startTimestamp;
            }
            else {
                // Check for video playback
                const videoPlayer = document.querySelector('[data-premid-title]');
                if (videoPlayer) {
                    const videoTitle = videoPlayer.getAttribute('data-premid-title');
                    const paused = videoPlayer.getAttribute('data-premid-paused') === 'true';
                    presenceData.details = videoTitle || 'Watching a Video';
                    presenceData.smallImageKey = paused ? Assets.Pause : Assets.Play;
                    presenceData.smallImageText = paused ? 'Paused' : 'Playing';
                    if (!paused) {
                        const video = document.querySelector('[data-premid-title] video');
                        if (video) {
                            [presenceData.startTimestamp, presenceData.endTimestamp] = getTimestampsFromMedia(video);
                        }
                    }
                    presenceData.state = paused ? '⏸ Paused' : '▶ Playing';
                }
                else {
                    presenceData.details = 'Browsing';
                    presenceData.state = 'Home Page';
                }
            }
        }
        else {
            presenceData.details = 'Browsing';
            presenceData.state = 'Home Page';
        }
    }
    // ─── Discography (3D Gallery) ───
    else if (pathname === '/releases') {
        presenceData.details = 'Browsing Archive';
        presenceData.state = 'Interactive Discography';
    }
    // ─── Individual Release Page ───
    else if (pathname.startsWith('/releases/')) {
        const releaseEl = document.querySelector('[data-premid-release-title]');
        const releaseTitle = releaseEl?.getAttribute('data-premid-release-title');
        presenceData.details = 'Viewing Release';
        presenceData.state = releaseTitle ? `🎵 ${releaseTitle}` : 'Release Page';
    }
    // ─── Upcoming Page ───
    else if (pathname === '/upcoming') {
        presenceData.details = 'Browsing';
        presenceData.state = 'Upcoming Releases';
    }
    // ─── Fallback ───
    else {
        presenceData.details = document.title || 'Browsing';
        presenceData.state = 'okiso.net';
    }
    if (presenceData.details)
        presence.setActivity(presenceData);
    else
        presence.setActivity();
});
//# sourceMappingURL=presence.js.map